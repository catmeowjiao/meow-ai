<div align="center">

# Meow AI

以标准的 OpenAI API 格式访问所有 LLM

</div>

安装:

- `pip install meow-ai`

使用:

- `meow-ai`